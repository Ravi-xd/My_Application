package com.example.newsapi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    public static final String apikey="e3c3611c72bb45ba8313017b57a8ce4f";

    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loadjson();
    }
    public void loadjson()
    {
        ApiIntrface apiIntrface=ApiClient.getClient().create(ApiIntrface.class);
        Call<Example> call=apiIntrface.getNews("in",apikey);
        call.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, Response<Example> response) {
                if(response.isSuccessful())
                {
                    //articleList=response.body().getArticles();
                    //Example example=response.body();
                    List<Article> articleList= (List<Article>) response.body().getArticles();
                    Log.e(TAG, "onResponse: ", (Throwable) articleList);
                }

            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
               // Log.e(TAG, "onFailure: ",t.getLocalizedMessage());
            }
        });
    }
}
